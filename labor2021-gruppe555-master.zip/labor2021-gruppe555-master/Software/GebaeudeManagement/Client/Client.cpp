#include "Client.h"


Client::Client(char _server[], char _port[]) {

}

void Client::sendRequest(const char request[], char answer[]) {
}

Client::~Client() {

}
